import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, startOfDay, endOfDay, subDays, eachDayOfInterval } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import Header from '@/components/layout/Header';
import BottomNavigation from '@/components/layout/BottomNavigation';
import WaterAddModal from '@/components/hydration/WaterAddModal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Droplet, Plus, Calendar as CalendarIcon, TrendingUp } from 'lucide-react';
import { useWaterTracking } from '@/hooks/use-water-tracking';

export default function HydrationPage() {
  // Mock user for now - would come from auth context
  const user = { id: 1, username: 'testuser', dailyWaterGoal: 2000 };
  
  const [isWaterModalOpen, setIsWaterModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('day');
  
  const { waterStats, addWaterIntake, updateWaterGoal, fetchWaterIntake } = useWaterTracking(user.id, user.dailyWaterGoal);
  
  // Fetch water history for chart
  const { data: waterHistory } = useQuery({
    queryKey: [`/api/users/${user.id}/water-intake`],
    enabled: !!user.id,
  });
  
  // Load water intake data for selected date
  useEffect(() => {
    if (user.id && selectedDate) {
      fetchWaterIntake(selectedDate);
    }
  }, [user.id, selectedDate, fetchWaterIntake]);
  
  // Prepare data for the chart based on view mode
  const getChartData = () => {
    if (!waterHistory) return [];
    
    let dateRange;
    let intervalLabel;
    
    switch (viewMode) {
      case 'week':
        dateRange = eachDayOfInterval({
          start: subDays(new Date(), 6),
          end: new Date()
        });
        intervalLabel = (date: Date) => format(date, 'EEE');
        break;
      case 'month':
        dateRange = eachDayOfInterval({
          start: subDays(new Date(), 29),
          end: new Date()
        });
        intervalLabel = (date: Date) => format(date, 'dd');
        break;
      case 'day':
      default:
        // For day view, split the day into hours
        dateRange = Array.from({ length: 24 }).map((_, i) => {
          const date = new Date(selectedDate);
          date.setHours(i);
          return date;
        });
        intervalLabel = (date: Date) => format(date, 'HH:00');
    }
    
    // Map date range to data points
    return dateRange.map(date => {
      // Filter water intake entries for this date/hour
      let totalAmount = 0;
      
      if (viewMode === 'day') {
        // For day view, filter by hour
        const hourStart = new Date(date);
        const hourEnd = new Date(date);
        hourEnd.setHours(hourEnd.getHours() + 1);
        
        totalAmount = waterHistory
          .filter((entry: any) => {
            const entryDate = new Date(entry.timestamp);
            return entryDate >= hourStart && entryDate < hourEnd;
          })
          .reduce((sum: number, entry: any) => sum + entry.amount, 0);
      } else {
        // For week/month view, filter by day
        const dayStart = startOfDay(date);
        const dayEnd = endOfDay(date);
        
        totalAmount = waterHistory
          .filter((entry: any) => {
            const entryDate = new Date(entry.timestamp);
            return entryDate >= dayStart && entryDate <= dayEnd;
          })
          .reduce((sum: number, entry: any) => sum + entry.amount, 0);
      }
      
      return {
        name: intervalLabel(date),
        amount: totalAmount
      };
    });
  };
  
  const chartData = getChartData();
  
  const handleAddWaterIntake = (amount: number) => {
    addWaterIntake(amount);
  };
  
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col relative">
      <Header username={user.username} />
      
      <main className="flex-1 overflow-y-auto pb-16">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <h1 className="text-2xl font-bold mb-3">Hydration Tracker</h1>
          <Card className="bg-white text-primary">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="relative w-16 h-16">
                    <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 100 100">
                      <circle 
                        className="text-blue-100" 
                        cx="50" 
                        cy="50" 
                        r="45" 
                        stroke="currentColor" 
                        strokeWidth="10" 
                        fill="none"
                      />
                      <circle 
                        className="text-primary" 
                        cx="50" 
                        cy="50" 
                        r="45" 
                        stroke="currentColor" 
                        strokeWidth="10" 
                        fill="none" 
                        strokeDasharray="283" 
                        strokeDashoffset={283 - (283 * waterStats.percentage / 100)}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Droplet className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-500">Today's intake</p>
                    <p className="text-2xl font-bold">{(waterStats.totalAmount / 1000).toFixed(1)} L</p>
                  </div>
                </div>
                <div>
                  <Button 
                    onClick={() => setIsWaterModalOpen(true)}
                    className="bg-primary"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Water
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="chart" className="p-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="chart">
              <TrendingUp className="mr-2 h-4 w-4" />
              Statistics
            </TabsTrigger>
            <TabsTrigger value="calendar">
              <CalendarIcon className="mr-2 h-4 w-4" />
              Calendar
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="chart">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Water Intake History</CardTitle>
                <div className="flex space-x-2">
                  <Button 
                    variant={viewMode === 'day' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setViewMode('day')}
                  >
                    Day
                  </Button>
                  <Button 
                    variant={viewMode === 'week' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setViewMode('week')}
                  >
                    Week
                  </Button>
                  <Button 
                    variant={viewMode === 'month' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setViewMode('month')}
                  >
                    Month
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value: number) => [`${value} ml`, 'Water']}
                        labelFormatter={(label) => `Time: ${label}`}
                      />
                      <Bar 
                        dataKey="amount" 
                        fill="hsl(217, 91%, 60%)" 
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Daily Goal: {(waterStats.goal / 1000).toFixed(1)} L</h3>
                  <div className="h-2 bg-blue-100 rounded-full">
                    <div 
                      className="h-2 bg-primary rounded-full"
                      style={{ width: `${waterStats.percentage}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between mt-1 text-xs text-gray-500">
                    <span>0 L</span>
                    <span>{(waterStats.goal / 1000).toFixed(1)} L</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="calendar">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Daily Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  className="rounded-md border"
                />
                
                <div className="mt-6">
                  <h3 className="text-sm font-medium mb-2">Water intake for {format(selectedDate, 'MMMM d, yyyy')}</h3>
                  {waterStats.entries.length > 0 ? (
                    <ul className="space-y-2">
                      {waterStats.entries.map((entry, index) => (
                        <li key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                          <div className="flex items-center">
                            <Droplet className="h-5 w-5 text-blue-500 mr-2" />
                            <span>{entry.amount} ml</span>
                          </div>
                          <span className="text-xs text-gray-500">
                            {format(new Date(entry.timestamp), 'h:mm a')}
                          </span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500 text-center py-4">No water intake recorded for this day.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <BottomNavigation />
      
      <WaterAddModal 
        onAddWater={handleAddWaterIntake}
        open={isWaterModalOpen}
        onOpenChange={setIsWaterModalOpen}
      />
    </div>
  );
}
