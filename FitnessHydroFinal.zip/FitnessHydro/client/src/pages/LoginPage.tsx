import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Droplet } from "lucide-react";
import LoginForm from "@/components/auth/LoginForm";
import RegisterForm from "@/components/auth/RegisterForm";

export default function LoginPage() {
  const [isLoginView, setIsLoginView] = useState(true);

  const toggleForm = () => {
    setIsLoginView(!isLoginView);
  };

  return (
    <div className="min-h-screen relative flex flex-col justify-center items-center p-4">
      <div className="absolute inset-0 z-0 bg-blue-100">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-400/20 to-blue-600/40"></div>
      </div>
      
      <div className="w-full max-w-md mx-auto z-10">
        <div className="flex justify-center mb-8">
          <div className="flex items-center justify-center h-20 w-20 rounded-full bg-white shadow-lg">
            <Droplet className="h-10 w-10 text-blue-500" />
          </div>
        </div>
        
        <h1 className="text-4xl font-bold text-center text-blue-900 mb-2 drop-shadow-sm">HydroTrack</h1>
        <p className="text-center text-blue-800 mb-8 max-w-xs mx-auto">
          Track your hydration, improve your health
        </p>
        
        <Card>
          <CardContent className="pt-6">
            {isLoginView ? (
              <LoginForm onToggleForm={toggleForm} />
            ) : (
              <RegisterForm onToggleForm={toggleForm} />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
