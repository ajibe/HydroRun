import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import Header from '@/components/layout/Header';
import BottomNavigation from '@/components/layout/BottomNavigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { User, Settings, LogOut, Award, Activity } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '@/hooks/use-toast';

const profileSchema = z.object({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  dailyWaterGoal: z.coerce.number().min(500, {
    message: "Water goal must be at least 500ml.",
  }).max(5000, {
    message: "Water goal must be at most 5000ml.",
  }),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilePage() {
  const { user, logout, updateUserData } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch user's activities
  const { data: activities } = useQuery({
    queryKey: [`/api/users/${user?.id}/activities`],
    enabled: !!user?.id,
  });
  
  // Total distance covered from all activities
  const totalDistance = activities?.reduce((sum: number, activity: any) => sum + activity.distance, 0) || 0;
  
  // Total time spent on activities (in minutes)
  const totalTimeMinutes = activities?.reduce((sum: number, activity: any) => sum + (activity.duration / 60000), 0) || 0;
  
  // Activity count
  const activitiesCount = activities?.length || 0;
  
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      username: user?.username || '',
      email: user?.email || '',
      dailyWaterGoal: user?.dailyWaterGoal || 2000,
    },
  });
  
  async function onSubmit(values: ProfileFormValues) {
    setIsSubmitting(true);
    try {
      await updateUserData(values);
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
    } catch (error) {
      console.error("Update error:", error);
    } finally {
      setIsSubmitting(false);
    }
  }
  
  const handleLogout = () => {
    logout();
  };
  
  if (!user) return null;
  
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col relative">
      <Header username={user.username} onLogout={handleLogout} />
      
      <main className="flex-1 overflow-y-auto pb-16">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <div className="flex items-center mb-6">
            <Avatar className="h-16 w-16 border-2 border-white mr-4">
              <AvatarImage src={user.profilePicture} alt={user.username} />
              <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold">{user.username}</h1>
              <p className="text-sm text-white text-opacity-90">{user.email}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3 mb-2">
            <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
              <p className="text-xl font-bold">{activitiesCount}</p>
              <p className="text-xs opacity-80">Activities</p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
              <p className="text-xl font-bold">{totalDistance.toFixed(1)}</p>
              <p className="text-xs opacity-80">Total KM</p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
              <p className="text-xl font-bold">{Math.round(totalTimeMinutes)}</p>
              <p className="text-xs opacity-80">Minutes</p>
            </div>
          </div>
        </div>
        
        <Tabs defaultValue="stats" className="p-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="stats">
              <Award className="mr-2 h-4 w-4" />
              Stats & Achievements
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="stats">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Activity Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Activity className="h-5 w-5 text-primary mr-2" />
                      <span>Total Activities</span>
                    </div>
                    <span className="font-bold">{activitiesCount}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                      </svg>
                      <span>Total Distance</span>
                    </div>
                    <span className="font-bold">{totalDistance.toFixed(1)} km</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>Total Time</span>
                    </div>
                    <span className="font-bold">{Math.floor(totalTimeMinutes / 60)}h {Math.round(totalTimeMinutes % 60)}m</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      <span>Avg. Pace</span>
                    </div>
                    <span className="font-bold">
                      {totalDistance > 0 
                        ? `${Math.floor((totalTimeMinutes / totalDistance) / 60)}:${Math.round((totalTimeMinutes / totalDistance) % 60).toString().padStart(2, '0')}/km` 
                        : '--:--/km'}
                    </span>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-sm font-medium mb-2">Achievements</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className={`border rounded-lg p-3 text-center ${totalDistance >= 5 ? 'border-primary' : 'border-gray-200 opacity-50'}`}>
                      <div className="flex justify-center">
                        <Award className={`h-8 w-8 ${totalDistance >= 5 ? 'text-primary' : 'text-gray-300'}`} />
                      </div>
                      <p className="font-medium mt-1">5K Runner</p>
                      <p className="text-xs text-gray-500">Run 5 kilometers total</p>
                    </div>
                    <div className={`border rounded-lg p-3 text-center ${activitiesCount >= 5 ? 'border-primary' : 'border-gray-200 opacity-50'}`}>
                      <div className="flex justify-center">
                        <Award className={`h-8 w-8 ${activitiesCount >= 5 ? 'text-primary' : 'text-gray-300'}`} />
                      </div>
                      <p className="font-medium mt-1">Consistent Runner</p>
                      <p className="text-xs text-gray-500">Complete 5 activities</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Profile Settings</CardTitle>
                <CardDescription>
                  Update your profile information and preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="dailyWaterGoal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Daily Water Goal (ml)</FormLabel>
                          <FormControl>
                            <Input type="number" min={500} max={5000} step={100} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <span className="flex items-center">
                          <span className="animate-spin mr-2 h-4 w-4 border-t-2 border-b-2 border-white rounded-full"></span>
                          Saving...
                        </span>
                      ) : (
                        "Save Changes"
                      )}
                    </Button>
                  </form>
                </Form>
                
                <Separator className="my-6" />
                
                <div>
                  <h3 className="text-sm font-medium mb-4">Account Actions</h3>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" className="w-full">
                        <LogOut className="mr-2 h-4 w-4" />
                        Logout
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure you want to logout?</AlertDialogTitle>
                        <AlertDialogDescription>
                          You will need to login again to access your account.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleLogout}>Logout</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
