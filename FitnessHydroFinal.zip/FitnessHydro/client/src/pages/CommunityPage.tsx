import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/Header';
import BottomNavigation from '@/components/layout/BottomNavigation';
import CommunityFeed from '@/components/social/CommunityFeed';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, PenSquare, MapPin, User, Image, Send } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

export default function CommunityPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [postContent, setPostContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch community posts
  const { data: communityPosts, isLoading, refetch } = useQuery({
    queryKey: ['/api/posts'],
  });
  
  // Fetch user activities for sharing
  const { data: userActivities } = useQuery({
    queryKey: [`/api/users/${user?.id}/activities`],
    enabled: !!user?.id,
  });
  
  // Format posts for display
  const formattedPosts = communityPosts?.map((post: any) => ({
    id: post.id,
    user: {
      id: post.userId,
      username: user?.id === post.userId ? user?.username : `User ${post.userId}`,
      profilePicture: user?.id === post.userId ? user?.profilePicture : undefined,
    },
    content: post.content,
    timestamp: post.timestamp,
    imagePath: post.imagePath,
    likesCount: 24, // Mock count since we don't have this in the API response yet
    commentsCount: 8, // Mock count since we don't have this in the API response yet
    distance: post.activityId ? 5.2 : undefined, // Mock distance for activity posts
    isLiked: false, // Would come from API
  })) || [];
  
  const handleRefreshFeed = async () => {
    await refetch();
  };
  
  const handleCreatePost = async () => {
    if (!postContent.trim()) {
      toast({
        title: "Error",
        description: "Post content cannot be empty",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/posts', {
        userId: user?.id,
        content: postContent,
        // In a real app, we would handle image uploads here
      });
      
      // Clear form and close modal
      setPostContent('');
      setIsPostModalOpen(false);
      
      // Refetch posts
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      
      toast({
        title: "Success",
        description: "Your post has been shared with the community",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create post",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleLikePost = async (postId: number) => {
    try {
      await apiRequest('POST', '/api/likes', {
        userId: user?.id,
        postId
      });
      
      // In a real app, we would update the likes count and liked status
      toast({
        title: "Success",
        description: "Post liked",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to like post",
        variant: "destructive"
      });
    }
  };
  
  const handleCommentPost = (postId: number) => {
    toast({
      title: "Comments",
      description: "Comments feature coming soon",
    });
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col relative">
      <Header username={user?.username} />
      
      <main className="flex-1 overflow-y-auto pb-16">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <div className="flex justify-between items-center mb-3">
            <h1 className="text-2xl font-bold">Community</h1>
            <Dialog open={isPostModalOpen} onOpenChange={setIsPostModalOpen}>
              <DialogTrigger asChild>
                <Button variant="secondary" size="sm">
                  <PenSquare className="mr-2 h-4 w-4" />
                  New Post
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create a Post</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <Textarea 
                    placeholder="What's on your mind?"
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    className="min-h-[120px]"
                  />
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Image className="mr-2 h-4 w-4" />
                      Add Photo
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <MapPin className="mr-2 h-4 w-4" />
                      Share Activity
                    </Button>
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={handleCreatePost} 
                    disabled={isSubmitting || !postContent.trim()}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <span className="animate-spin mr-2 h-4 w-4 border-t-2 border-b-2 border-white rounded-full"></span>
                        Posting...
                      </span>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Post
                      </>
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          <p className="mb-4 text-white text-opacity-90">
            Share your runs and connect with other runners in your area
          </p>
        </div>
        
        <Tabs defaultValue="feed" className="p-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="feed">
              <Users className="mr-2 h-4 w-4" />
              Community Feed
            </TabsTrigger>
            <TabsTrigger value="nearby">
              <MapPin className="mr-2 h-4 w-4" />
              Runners Nearby
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="feed">
            {isLoading ? (
              <div className="flex justify-center p-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : (
              <CommunityFeed 
                posts={formattedPosts}
                onRefresh={handleRefreshFeed}
                onLikePost={handleLikePost}
                onCommentPost={handleCommentPost}
              />
            )}
          </TabsContent>
          
          <TabsContent value="nearby">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Nearby Runners</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="py-8 text-center">
                  <User className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium mb-2">Discover Runners Nearby</h3>
                  <p className="text-gray-500 mb-4">
                    We're working on helping you connect with runners in your area.
                    This feature will be available soon!
                  </p>
                  <Button>Notify Me When Available</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
