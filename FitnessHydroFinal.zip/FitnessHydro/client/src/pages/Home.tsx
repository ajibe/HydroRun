import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/Header';
import BottomNavigation from '@/components/layout/BottomNavigation';
import DashboardOverview from '@/components/dashboard/DashboardOverview';
import WaterTracker from '@/components/hydration/WaterTracker';
import WaterAddModal from '@/components/hydration/WaterAddModal';
import ActivityCard from '@/components/activity/ActivityCard';
import NearbyPaths from '@/components/activity/NearbyPaths';
import ActivityRecordingModal from '@/components/activity/ActivityRecordingModal';
import CommunityFeed from '@/components/social/CommunityFeed';
import RecordButton from '@/components/ui/RecordButton';
import { Button } from '@/components/ui/button';
import { useWaterTracking, WaterIntake } from '@/hooks/use-water-tracking';
import { useToast } from '@/hooks/use-toast';
import { formatDistance, format } from 'date-fns';

export default function Home() {
  const { toast } = useToast();
  const [isWaterModalOpen, setIsWaterModalOpen] = useState(false);
  const [isRecordingModalOpen, setIsRecordingModalOpen] = useState(false);
  
  // Mock user for now - would come from auth context
  const user = { id: 1, username: 'testuser', dailyWaterGoal: 2000 };
  
  // Water tracking logic
  const { waterStats, addWaterIntake, updateWaterGoal } = useWaterTracking(user.id, user.dailyWaterGoal);
  
  // Fetch user's recent activity
  const { data: recentActivities } = useQuery({
    queryKey: [`/api/users/${user.id}/activities`],
    enabled: !!user.id,
  });
  
  // Fetch nearby paths with geolocation
  const [nearbyPaths, setNearbyPaths] = useState([
    {
      id: 1,
      title: 'City Park Loop',
      description: 'Popular morning route along the river',
      distance: 2.4,
      imageUrl: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80',
      runnersCount: 28
    },
    {
      id: 2,
      title: 'Forest Trail',
      description: 'Scenic route with moderate hills',
      distance: 3.7,
      imageUrl: 'https://images.unsplash.com/photo-1602573991155-21f0143c2a26?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80',
      runnersCount: 12
    }
  ]);
  
  // Fetch community posts
  const { data: communityPosts, refetch: refetchPosts } = useQuery({
    queryKey: ['/api/posts'],
  });
  
  // Format activities and posts for display
  const formattedActivities = recentActivities?.[0] ? [{
    title: recentActivities[0].title,
    date: formatDistance(new Date(recentActivities[0].timestamp), new Date(), { addSuffix: true }),
    imageUrl: 'https://images.unsplash.com/photo-1591258370814-01609b341790?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80',
    distance: recentActivities[0].distance,
    duration: formatDuration(recentActivities[0].duration),
    pace: formatPace(recentActivities[0].distance, recentActivities[0].duration),
    elevationGain: recentActivities[0].elevationGain || 0,
    weather: recentActivities[0].weather || 'Unknown',
    temperature: recentActivities[0].temperature || 0
  }] : [];
  
  const formattedPosts = communityPosts?.map((post: any) => ({
    id: post.id,
    user: {
      id: post.userId,
      username: 'User ' + post.userId,
      profilePicture: undefined
    },
    content: post.content,
    timestamp: post.timestamp,
    imagePath: post.imagePath,
    likesCount: 0, // Would come from API
    commentsCount: 0, // Would come from API
    isLiked: false
  })) || [];
  
  // Activity stats for dashboard
  const activityStats = {
    totalDistance: recentActivities?.reduce((sum: number, activity: any) => sum + activity.distance, 0) || 0,
    totalTime: recentActivities?.reduce((sum: number, activity: any) => sum + activity.duration, 0) || 0,
    averagePace: formatPace(
      recentActivities?.reduce((sum: number, activity: any) => sum + activity.distance, 0) || 0,
      recentActivities?.reduce((sum: number, activity: any) => sum + activity.duration, 0) || 0
    ),
    caloriesBurned: calculateCaloriesBurned(
      recentActivities?.reduce((sum: number, activity: any) => sum + activity.distance, 0) || 0,
      recentActivities?.reduce((sum: number, activity: any) => sum + activity.duration, 0) || 0
    )
  };
  
  // Helper functions
  function formatDuration(ms: number) {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }
  
  function formatPace(distance: number, duration: number) {
    if (distance === 0) return '--:--';
    
    const paceSeconds = duration / 1000 / distance;
    const paceMinutes = Math.floor(paceSeconds / 60);
    const remainingSeconds = Math.floor(paceSeconds % 60);
    
    return `${paceMinutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  
  function calculateCaloriesBurned(distance: number, duration: number) {
    // Simple estimation: 60 calories per km
    return Math.round(distance * 60);
  }
  
  const handleAddWaterIntake = (amount: number) => {
    addWaterIntake(amount);
  };
  
  const handleShareActivity = () => {
    toast({
      title: "Sharing",
      description: "Activity sharing is not implemented yet"
    });
  };
  
  const handleEditActivity = () => {
    toast({
      title: "Editing",
      description: "Activity editing is not implemented yet"
    });
  };
  
  const handleSelectPath = (pathId: number) => {
    toast({
      title: "Path Selected",
      description: `You selected path #${pathId}`
    });
  };
  
  const handleFinishRecording = (activityData: any) => {
    toast({
      title: "Activity Recorded",
      description: `You recorded ${activityData.distance.toFixed(2)}km in ${formatDuration(activityData.elapsedTime)}`
    });
    
    // Would submit to API in a real app
    console.log('Activity data:', activityData);
  };
  
  const handleLikePost = (postId: number) => {
    toast({
      title: "Like",
      description: `You liked post #${postId}`
    });
  };
  
  const handleCommentPost = (postId: number) => {
    toast({
      title: "Comment",
      description: `Add a comment to post #${postId}`
    });
  };
  
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col relative">
      <Header username={user.username} />
      
      <main className="flex-1 overflow-y-auto pb-16">
        {/* Dashboard Overview */}
        <DashboardOverview 
          waterProgress={waterStats.percentage}
          waterCurrent={waterStats.totalAmount}
          waterGoal={waterStats.goal}
          totalDistance={activityStats.totalDistance}
          totalTime={activityStats.totalTime}
          averagePace={activityStats.averagePace}
          caloriesBurned={activityStats.caloriesBurned}
        />
        
        {/* Water Tracker */}
        <WaterTracker 
          waterIntakes={waterStats.entries}
          onAddWaterIntake={() => setIsWaterModalOpen(true)}
          onSetWaterGoal={updateWaterGoal}
          currentGoal={waterStats.goal}
        />
        
        {/* Activity Section */}
        <section className="p-4 border-b">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-semibold">Recent Activity</h2>
            <Button variant="link" className="text-primary text-sm font-medium p-0">View All</Button>
          </div>
          
          {formattedActivities.length > 0 ? (
            <ActivityCard
              title={formattedActivities[0].title}
              date={formattedActivities[0].date}
              imageUrl={formattedActivities[0].imageUrl}
              distance={formattedActivities[0].distance}
              duration={formattedActivities[0].duration}
              pace={formattedActivities[0].pace}
              elevationGain={formattedActivities[0].elevationGain}
              weather={formattedActivities[0].weather}
              temperature={formattedActivities[0].temperature}
              onShare={handleShareActivity}
              onEdit={handleEditActivity}
            />
          ) : (
            <div className="bg-white border rounded-xl p-6 text-center mb-4">
              <p className="text-gray-500">No recent activities. Start tracking your runs!</p>
            </div>
          )}
          
          <NearbyPaths 
            paths={nearbyPaths}
            onSelectPath={handleSelectPath}
          />
        </section>
        
        {/* Community Feed */}
        <CommunityFeed 
          posts={formattedPosts}
          onRefresh={refetchPosts}
          onLikePost={handleLikePost}
          onCommentPost={handleCommentPost}
        />
      </main>
      
      {/* Record Activity Button */}
      <RecordButton onClick={() => setIsRecordingModalOpen(true)} />
      
      {/* Bottom Navigation */}
      <BottomNavigation />
      
      {/* Modals */}
      <WaterAddModal 
        onAddWater={handleAddWaterIntake}
        open={isWaterModalOpen}
        onOpenChange={setIsWaterModalOpen}
      />
      
      <ActivityRecordingModal 
        open={isRecordingModalOpen}
        onOpenChange={setIsRecordingModalOpen}
        onFinishRecording={handleFinishRecording}
      />
    </div>
  );
}
