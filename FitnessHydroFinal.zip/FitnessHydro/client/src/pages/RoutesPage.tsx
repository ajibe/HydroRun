import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/Header';
import BottomNavigation from '@/components/layout/BottomNavigation';
import ActivityCard from '@/components/activity/ActivityCard';
import ActivityRecordingModal from '@/components/activity/ActivityRecordingModal';
import RecordButton from '@/components/ui/RecordButton';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Route, History, Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow, format } from 'date-fns';
import { useGeolocation } from '@/hooks/use-geolocation';

export default function RoutesPage() {
  const { toast } = useToast();
  const [isRecordingModalOpen, setIsRecordingModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Mock user for now - would come from auth context
  const user = { id: 1, username: 'testuser' };
  
  // Geolocation for nearby routes
  const { getCurrentPosition } = useGeolocation();
  const [userLocation, setUserLocation] = useState<{latitude: number, longitude: number} | null>(null);
  
  // Fetch user's activities
  const { data: activities } = useQuery({
    queryKey: [`/api/users/${user.id}/activities`],
    enabled: !!user.id,
  });
  
  // Fetch nearby routes
  const { data: nearbyRoutes, refetch: refetchNearbyRoutes } = useQuery({
    queryKey: ['/api/activities/nearby'],
    enabled: !!userLocation,
    queryFn: async () => {
      if (!userLocation) return [];
      
      // We're using the normal fetch queryFn here since we need to pass query params
      const response = await fetch(
        `/api/activities/nearby?lat=${userLocation.latitude}&lng=${userLocation.longitude}&radius=5`,
        { credentials: 'include' }
      );
      
      if (!response.ok) throw new Error('Failed to fetch nearby routes');
      return response.json();
    }
  });
  
  // Get user location on mount
  useEffect(() => {
    const fetchLocation = async () => {
      try {
        const position = await getCurrentPosition();
        setUserLocation({
          latitude: position.latitude,
          longitude: position.longitude
        });
      } catch (error) {
        console.error('Error getting location:', error);
        toast({
          title: 'Location Error',
          description: 'Could not get your current location. Some features may be limited.',
          variant: 'destructive'
        });
      }
    };
    
    fetchLocation();
  }, [getCurrentPosition, toast]);
  
  // Format activities for display
  const formattedActivities = activities?.map((activity: any) => ({
    id: activity.id,
    title: activity.title,
    date: formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true }),
    imageUrl: 'https://images.unsplash.com/photo-1591258370814-01609b341790?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80', // Placeholder
    distance: activity.distance,
    duration: formatDuration(activity.duration),
    pace: formatPace(activity.distance, activity.duration),
    elevationGain: activity.elevationGain || 0,
    weather: activity.weather || 'Unknown',
    temperature: activity.temperature || 0
  })) || [];
  
  // Filter activities by search term
  const filteredActivities = formattedActivities.filter(activity => 
    activity.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Helper functions
  function formatDuration(ms: number) {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }
  
  function formatPace(distance: number, duration: number) {
    if (distance === 0) return '--:--';
    
    const paceSeconds = duration / 1000 / distance;
    const paceMinutes = Math.floor(paceSeconds / 60);
    const remainingSeconds = Math.floor(paceSeconds % 60);
    
    return `${paceMinutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  
  const handleFinishRecording = (activityData: any) => {
    toast({
      title: "Activity Recorded",
      description: `You recorded ${activityData.distance.toFixed(2)}km in ${formatDuration(activityData.elapsedTime)}`
    });
    
    // Would submit to API in a real app
    console.log('Activity data:', activityData);
  };
  
  const handleShareActivity = () => {
    toast({
      title: "Sharing",
      description: "Activity sharing is not implemented yet"
    });
  };
  
  const handleEditActivity = () => {
    toast({
      title: "Editing",
      description: "Activity editing is not implemented yet"
    });
  };
  
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col relative">
      <Header username={user.username} />
      
      <main className="flex-1 overflow-y-auto pb-16">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <h1 className="text-2xl font-bold mb-3">Your Routes</h1>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search activities..."
              className="pl-10 bg-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>
        
        <Tabs defaultValue="myRoutes" className="p-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="myRoutes">
              <History className="mr-2 h-4 w-4" />
              My Activities
            </TabsTrigger>
            <TabsTrigger value="explore">
              <MapPin className="mr-2 h-4 w-4" />
              Explore Nearby
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="myRoutes">
            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-lg font-semibold">Your Recent Activities</h2>
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
            
            {filteredActivities.length > 0 ? (
              <div className="space-y-4">
                {filteredActivities.map((activity) => (
                  <ActivityCard
                    key={activity.id}
                    title={activity.title}
                    date={activity.date}
                    imageUrl={activity.imageUrl}
                    distance={activity.distance}
                    duration={activity.duration}
                    pace={activity.pace}
                    elevationGain={activity.elevationGain}
                    weather={activity.weather}
                    temperature={activity.temperature}
                    onShare={handleShareActivity}
                    onEdit={handleEditActivity}
                  />
                ))}
              </div>
            ) : (
              <Card className="mt-4">
                <CardContent className="p-8 text-center">
                  <Route className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Activities Found</h3>
                  <p className="text-gray-500 mb-4">
                    {searchTerm ? 'No matching activities found. Try a different search term.' : 'You haven\'t recorded any activities yet.'}
                  </p>
                  {!searchTerm && (
                    <Button onClick={() => setIsRecordingModalOpen(true)}>
                      Record Your First Activity
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="explore">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Popular Routes Nearby</CardTitle>
              </CardHeader>
              <CardContent>
                {nearbyRoutes && nearbyRoutes.length > 0 ? (
                  <div className="space-y-4">
                    {nearbyRoutes.map((route: any) => (
                      <div key={route.id} className="border rounded-lg p-3 hover:border-primary cursor-pointer transition-colors">
                        <div className="flex justify-between">
                          <h3 className="font-medium">{route.title || 'Unnamed Route'}</h3>
                          <span className="text-sm text-gray-500">{route.distance.toFixed(1)} km</span>
                        </div>
                        <div className="flex justify-between mt-2">
                          <span className="text-sm text-gray-600">
                            {format(new Date(route.timestamp), 'MMM d, yyyy')}
                          </span>
                          <span className="text-sm text-primary font-medium">View Details</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MapPin className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Routes Found Nearby</h3>
                    <p className="text-gray-500 mb-4">
                      Try expanding your search area or be the first to share a route in this area!
                    </p>
                    <Button onClick={() => setIsRecordingModalOpen(true)}>
                      Record a New Route
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <RecordButton onClick={() => setIsRecordingModalOpen(true)} />
      
      <BottomNavigation />
      
      <ActivityRecordingModal 
        open={isRecordingModalOpen}
        onOpenChange={setIsRecordingModalOpen}
        onFinishRecording={handleFinishRecording}
      />
    </div>
  );
}
