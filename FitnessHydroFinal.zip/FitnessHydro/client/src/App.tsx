import { Switch, Route } from "wouter";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import HydrationPage from "@/pages/HydrationPage";
import RoutesPage from "@/pages/RoutesPage";
import CommunityPage from "@/pages/CommunityPage";
import ProfilePage from "@/pages/ProfilePage";
import LoginPage from "@/pages/LoginPage";
import { AuthProvider, useAuth } from "./context/AuthContext";

function AuthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/" component={Home}/>
      <Route path="/hydration" component={HydrationPage}/>
      <Route path="/routes" component={RoutesPage}/>
      <Route path="/community" component={CommunityPage}/>
      <Route path="/profile" component={ProfilePage}/>
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function UnauthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/" component={LoginPage} />
      <Route path="/login" component={LoginPage} />
      {/* Fallback routes to login */}
      <Route component={LoginPage} />
    </Switch>
  );
}

function AppContent() {
  const { user, isLoading } = useAuth();

  // If still loading, could show a loading spinner
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-blue-500 rounded-full"></div>
    </div>;
  }

  return user ? <AuthenticatedRoutes /> : <UnauthenticatedRoutes />;
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
