import { useState, useEffect } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export type WaterIntake = {
  id: number;
  userId: number;
  amount: number;
  timestamp: string;
};

export interface WaterStats {
  totalAmount: number;
  goal: number;
  percentage: number;
  entries: WaterIntake[];
}

export function useWaterTracking(userId: number | null, dailyGoal: number = 2000) {
  const [waterStats, setWaterStats] = useState<WaterStats>({
    totalAmount: 0,
    goal: dailyGoal,
    percentage: 0,
    entries: []
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchWaterIntake = async (date?: Date) => {
    if (!userId) return;
    
    setIsLoading(true);
    try {
      let url = `/api/users/${userId}/water-intake`;
      if (date) {
        url += `?date=${format(date, 'yyyy-MM-dd')}`;
      }
      
      const response = await fetch(url, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch water intake data');
      }
      
      const data = await response.json() as WaterIntake[];
      
      // Calculate total amount
      const totalAmount = data.reduce((sum, entry) => sum + entry.amount, 0);
      const percentage = Math.min(Math.round((totalAmount / waterStats.goal) * 100), 100);
      
      setWaterStats({
        totalAmount,
        goal: waterStats.goal,
        percentage,
        entries: data
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch water intake data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const addWaterIntake = async (amount: number) => {
    if (!userId || amount <= 0) return;
    
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/water-intake', {
        userId,
        amount
      });
      
      const newEntry = await response.json() as WaterIntake;
      
      // Update water stats
      const updatedTotalAmount = waterStats.totalAmount + amount;
      const updatedPercentage = Math.min(Math.round((updatedTotalAmount / waterStats.goal) * 100), 100);
      
      setWaterStats({
        totalAmount: updatedTotalAmount,
        goal: waterStats.goal,
        percentage: updatedPercentage,
        entries: [...waterStats.entries, newEntry]
      });
      
      toast({
        title: "Success",
        description: `Added ${amount}ml of water`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add water intake",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateWaterGoal = async (newGoal: number) => {
    if (!userId || newGoal <= 0) return;
    
    try {
      await apiRequest('PATCH', `/api/users/${userId}`, {
        dailyWaterGoal: newGoal
      });
      
      // Recalculate percentage with new goal
      const updatedPercentage = Math.min(Math.round((waterStats.totalAmount / newGoal) * 100), 100);
      
      setWaterStats({
        ...waterStats,
        goal: newGoal,
        percentage: updatedPercentage
      });
      
      toast({
        title: "Success",
        description: `Updated daily water goal to ${newGoal}ml`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update water goal",
        variant: "destructive"
      });
    }
  };

  // Load water intake data on mount or when userId changes
  useEffect(() => {
    if (userId) {
      fetchWaterIntake(new Date());
    }
  }, [userId]);

  return {
    waterStats,
    isLoading,
    fetchWaterIntake,
    addWaterIntake,
    updateWaterGoal
  };
}
