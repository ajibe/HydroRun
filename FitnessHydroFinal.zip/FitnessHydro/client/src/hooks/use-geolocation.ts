import { useState, useEffect, useRef, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';

export type Coordinates = {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp: number;
};

export type RouteCoordinates = Coordinates[];

export interface GeolocationState {
  coordinates: Coordinates | null;
  isRecording: boolean;
  routeCoordinates: RouteCoordinates;
  startTime: number | null;
  elapsedTime: number;
  distance: number;
  isPaused: boolean;
}

export function useGeolocation() {
  const [state, setState] = useState<GeolocationState>({
    coordinates: null,
    isRecording: false,
    routeCoordinates: [],
    startTime: null,
    elapsedTime: 0,
    distance: 0,
    isPaused: false
  });
  
  const [error, setError] = useState<string | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Function to calculate distance between two points using Haversine formula
  const calculateDistance = useCallback((lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // Distance in km
    return distance;
  }, []);

  // Start recording route
  const startRecording = useCallback(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      toast({
        title: "Error",
        description: "Geolocation is not supported by your browser",
        variant: "destructive"
      });
      return;
    }

    setState(prev => ({
      ...prev,
      isRecording: true,
      routeCoordinates: [],
      startTime: Date.now(),
      elapsedTime: 0,
      distance: 0,
      isPaused: false
    }));

    // Start timer for elapsed time
    timerRef.current = setInterval(() => {
      setState(prev => {
        if (prev.isPaused || !prev.startTime) return prev;
        return {
          ...prev,
          elapsedTime: Date.now() - prev.startTime
        };
      });
    }, 1000);

    // Start watching position
    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const newCoordinates = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp
        };

        setState(prev => {
          // If paused, don't update
          if (prev.isPaused) return prev;
          
          // Calculate new distance if we have previous coordinates
          let updatedDistance = prev.distance;
          
          if (prev.routeCoordinates.length > 0) {
            const lastCoord = prev.routeCoordinates[prev.routeCoordinates.length - 1];
            const newDistanceSegment = calculateDistance(
              lastCoord.latitude,
              lastCoord.longitude,
              newCoordinates.latitude,
              newCoordinates.longitude
            );
            updatedDistance += newDistanceSegment;
          }

          return {
            ...prev,
            coordinates: newCoordinates,
            routeCoordinates: [...prev.routeCoordinates, newCoordinates],
            distance: updatedDistance
          };
        });
      },
      (positionError) => {
        setError(positionError.message);
        toast({
          title: "Error",
          description: positionError.message,
          variant: "destructive"
        });
      },
      { 
        enableHighAccuracy: true, 
        maximumAge: 0,
        timeout: 5000
      }
    );
  }, [calculateDistance, toast]);

  // Pause recording
  const pauseRecording = useCallback(() => {
    setState(prev => ({
      ...prev,
      isPaused: true
    }));
  }, []);

  // Resume recording
  const resumeRecording = useCallback(() => {
    setState(prev => ({
      ...prev,
      isPaused: false
    }));
  }, []);

  // Stop recording
  const stopRecording = useCallback(() => {
    if (watchIdRef.current) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }

    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    // Return final route data
    const finalData = {
      routeCoordinates: state.routeCoordinates,
      distance: state.distance,
      elapsedTime: state.elapsedTime,
      startTime: state.startTime
    };

    setState(prev => ({
      ...prev,
      isRecording: false,
      isPaused: false
    }));

    return finalData;
  }, [state.elapsedTime, state.distance, state.routeCoordinates, state.startTime]);

  // Get current position once
  const getCurrentPosition = useCallback(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      toast({
        title: "Error",
        description: "Geolocation is not supported by your browser",
        variant: "destructive"
      });
      return Promise.reject(new Error('Geolocation is not supported'));
    }

    return new Promise<Coordinates>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coordinates = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp
          };
          
          setState(prev => ({
            ...prev,
            coordinates
          }));
          
          resolve(coordinates);
        },
        (positionError) => {
          setError(positionError.message);
          toast({
            title: "Error",
            description: positionError.message,
            variant: "destructive"
          });
          reject(new Error(positionError.message));
        },
        { 
          enableHighAccuracy: true, 
          maximumAge: 0,
          timeout: 5000
        }
      );
    });
  }, [toast]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  return {
    ...state,
    error,
    startRecording,
    pauseRecording,
    resumeRecording,
    stopRecording,
    getCurrentPosition
  };
}
