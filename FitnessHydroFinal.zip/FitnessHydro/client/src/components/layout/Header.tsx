import { useState } from 'react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Droplet, Bell, User, LogOut } from 'lucide-react';

interface HeaderProps {
  username?: string;
  onLogout?: () => void;
}

export default function Header({ username, onLogout }: HeaderProps) {
  const [hasNotifications, setHasNotifications] = useState(true);

  const handleNotifications = () => {
    setHasNotifications(false);
  };

  return (
    <header className="relative h-16 px-4 flex items-center justify-between bg-primary text-white shadow-md z-10">
      <div className="flex items-center">
        <Droplet className="h-8 w-8 mr-2" />
        <h1 className="font-bold text-xl">HydroTrack</h1>
      </div>
      
      <div className="flex items-center space-x-3">
        <button 
          onClick={handleNotifications}
          className="relative p-1 rounded-full hover:bg-blue-600 transition"
        >
          {hasNotifications && (
            <span className="absolute top-0 right-0 h-2 w-2 bg-orange-400 rounded-full"></span>
          )}
          <Bell className="h-6 w-6" />
        </button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="h-8 w-8 rounded-full bg-blue-700 border-2 border-white flex items-center justify-center overflow-hidden">
              {username ? (
                <span className="text-xs font-bold text-white">
                  {username.substring(0, 2).toUpperCase()}
                </span>
              ) : (
                <User className="h-5 w-5 text-white" />
              )}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="cursor-pointer">
              <User className="mr-2 h-4 w-4" />
              <span>Profile</span>
            </DropdownMenuItem>
            {onLogout && (
              <DropdownMenuItem onClick={onLogout} className="cursor-pointer">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
