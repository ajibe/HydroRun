import { Link, useLocation } from 'wouter';
import { Home, Map, Target, Users, User } from 'lucide-react';

export default function BottomNavigation() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t h-16 flex items-center z-10">
      <div className="max-w-md mx-auto w-full">
        <div className="flex justify-around">
          <Link href="/">
            <a className={`flex flex-col items-center ${location === '/' ? 'text-primary' : 'text-gray-500'}`}>
              <Home className="h-6 w-6" />
              <span className="text-xs mt-1">Home</span>
            </a>
          </Link>
          
          <Link href="/routes">
            <a className={`flex flex-col items-center ${location === '/routes' ? 'text-primary' : 'text-gray-500'}`}>
              <Map className="h-6 w-6" />
              <span className="text-xs mt-1">Routes</span>
            </a>
          </Link>
          
          <Link href="/hydration">
            <a className={`flex flex-col items-center ${location === '/hydration' ? 'text-primary' : 'text-gray-500'}`}>
              <Target className="h-6 w-6" />
              <span className="text-xs mt-1">Hydration</span>
            </a>
          </Link>
          
          <Link href="/community">
            <a className={`flex flex-col items-center ${location === '/community' ? 'text-primary' : 'text-gray-500'}`}>
              <Users className="h-6 w-6" />
              <span className="text-xs mt-1">Community</span>
            </a>
          </Link>
          
          <Link href="/profile">
            <a className={`flex flex-col items-center ${location === '/profile' ? 'text-primary' : 'text-gray-500'}`}>
              <User className="h-6 w-6" />
              <span className="text-xs mt-1">Profile</span>
            </a>
          </Link>
        </div>
      </div>
    </nav>
  );
}
