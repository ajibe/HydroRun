import { format } from 'date-fns';
import { Timer, Zap, Flame, TrendingUp } from 'lucide-react';

interface DashboardOverviewProps {
  waterProgress: number;
  waterCurrent: number;
  waterGoal: number;
  totalDistance: number;
  totalTime: number;
  averagePace: string;
  caloriesBurned: number;
}

export default function DashboardOverview({
  waterProgress,
  waterCurrent,
  waterGoal,
  totalDistance,
  totalTime,
  averagePace,
  caloriesBurned
}: DashboardOverviewProps) {
  const today = format(new Date(), 'EEEE, MMMM d');
  
  // Calculate time in minutes
  const displayMinutes = Math.floor(totalTime / 60000);
  
  return (
    <section className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Today's Progress</h2>
        <span>{today}</span>
      </div>
      
      <div className="flex items-center justify-between">
        {/* Water Intake Progress */}
        <div className="flex flex-col items-center">
          <div className="relative w-24 h-24">
            {/* Water Circle Progress */}
            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
              <circle 
                className="text-blue-300 opacity-25" 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="currentColor" 
                strokeWidth="10" 
                fill="none"
              />
              <circle 
                className="text-white" 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="currentColor" 
                strokeWidth="10" 
                fill="none" 
                strokeDasharray="283" 
                strokeDashoffset={283 - (283 * waterProgress / 100)}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold">{waterProgress}%</span>
              <span className="text-xs">of goal</span>
            </div>
          </div>
          <p className="mt-2 text-center font-medium">
            <span>{(waterCurrent / 1000).toFixed(1)}</span>/<span>{(waterGoal / 1000).toFixed(1)}</span> L
          </p>
          <p className="text-xs opacity-80">Hydration</p>
        </div>
        
        {/* Activity Stats */}
        <div className="flex flex-col">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <div className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-1" />
                <span className="text-xs">Distance</span>
              </div>
              <p className="font-bold text-lg">{totalDistance.toFixed(1)} km</p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <div className="flex items-center">
                <Timer className="h-5 w-5 mr-1" />
                <span className="text-xs">Time</span>
              </div>
              <p className="font-bold text-lg">{displayMinutes} min</p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <div className="flex items-center">
                <Zap className="h-5 w-5 mr-1" />
                <span className="text-xs">Pace</span>
              </div>
              <p className="font-bold text-lg">{averagePace}/km</p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <div className="flex items-center">
                <Flame className="h-5 w-5 mr-1" />
                <span className="text-xs">Calories</span>
              </div>
              <p className="font-bold text-lg">{caloriesBurned} cal</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
