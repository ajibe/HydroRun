import { Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface RecordButtonProps {
  onClick: () => void;
}

export default function RecordButton({ onClick }: RecordButtonProps) {
  return (
    <div className="fixed bottom-24 right-4 z-20">
      <Button
        onClick={onClick}
        size="lg"
        className="h-14 w-14 rounded-full bg-orange-400 hover:bg-orange-500 shadow-lg flex items-center justify-center text-white"
      >
        <Play className="h-7 w-7 ml-1" />
      </Button>
    </div>
  );
}
