import { useState } from 'react';
import { formatDistance } from 'date-fns';
import { Heart, MessageCircle, RefreshCw, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

interface PostUser {
  id: number;
  username: string;
  profilePicture?: string;
}

interface Post {
  id: number;
  user: PostUser;
  content: string;
  timestamp: string;
  imagePath?: string;
  likesCount: number;
  commentsCount: number;
  distance?: number;
  isLiked: boolean;
}

interface CommunityFeedProps {
  posts: Post[];
  onRefresh: () => void;
  onLikePost: (postId: number) => void;
  onCommentPost: (postId: number) => void;
}

export default function CommunityFeed({ 
  posts, 
  onRefresh, 
  onLikePost, 
  onCommentPost 
}: CommunityFeedProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await onRefresh();
    setIsRefreshing(false);
  };
  
  return (
    <section className="p-4">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold">Community Activity</h2>
        <Button 
          variant="link" 
          size="sm" 
          onClick={handleRefresh}
          className="text-primary p-0 flex items-center"
          disabled={isRefreshing}
        >
          <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>
      
      <div className="space-y-4">
        {posts.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-gray-500">No community posts yet. Check back later!</p>
          </Card>
        ) : (
          posts.map((post) => (
            <Card key={post.id} className="bg-white border rounded-lg shadow-sm overflow-hidden">
              <div className="p-3 flex items-center border-b">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src={post.user.profilePicture} alt={post.user.username} />
                  <AvatarFallback>{post.user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium">{post.user.username}</h4>
                  <p className="text-xs text-gray-500">
                    {formatDistance(new Date(post.timestamp), new Date(), { addSuffix: true })}
                  </p>
                </div>
              </div>
              
              <div className="p-3">
                <p className="text-sm mb-2">{post.content}</p>
                
                {post.imagePath && (
                  <div className="h-36 bg-gray-200 rounded-lg overflow-hidden mb-2">
                    <div 
                      className="h-full w-full bg-cover bg-center"
                      style={{ backgroundImage: `url(${post.imagePath})` }}
                    ></div>
                  </div>
                )}
                
                <div className="flex justify-between items-center text-sm">
                  <div className="flex items-center space-x-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onLikePost(post.id)}
                      className="flex items-center space-x-1 text-gray-500 p-0 h-auto"
                    >
                      <Heart 
                        className={`h-5 w-5 ${post.isLiked ? 'text-rose-500 fill-rose-500' : ''}`} 
                      />
                      <span>{post.likesCount}</span>
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onCommentPost(post.id)}
                      className="flex items-center space-x-1 text-gray-500 p-0 h-auto"
                    >
                      <MessageCircle className="h-5 w-5" />
                      <span>{post.commentsCount}</span>
                    </Button>
                  </div>
                  
                  {post.distance && (
                    <div className="flex items-center text-gray-500">
                      <span className="text-xs mr-1">{post.distance.toFixed(1)} km</span>
                      <MapPin className="h-4 w-4" />
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </section>
  );
}
