import { useState } from 'react';
import { format } from 'date-fns';
import { PlusIcon } from 'lucide-react';
import { WaterIntake } from '@/hooks/use-water-tracking';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';

interface WaterTrackerProps {
  waterIntakes: WaterIntake[];
  onAddWaterIntake: (amount: number) => void;
  onSetWaterGoal: (goal: number) => void;
  currentGoal: number;
}

export default function WaterTracker({ 
  waterIntakes, 
  onAddWaterIntake, 
  onSetWaterGoal, 
  currentGoal 
}: WaterTrackerProps) {
  const [reminderTime, setReminderTime] = useState('16:00');
  const [isGoalDialogOpen, setIsGoalDialogOpen] = useState(false);
  const [newGoal, setNewGoal] = useState(currentGoal);
  
  // Group water intakes by hour
  const waterIntakesByHour = waterIntakes.reduce<Record<string, number>>((acc, intake) => {
    const hour = new Date(intake.timestamp).getHours();
    const hourKey = `${hour}:00`;
    
    if (!acc[hourKey]) {
      acc[hourKey] = 0;
    }
    
    acc[hourKey] += intake.amount;
    return acc;
  }, {});
  
  // Get the latest 4 water intakes by hour
  const latestWaterIntakes = Object.entries(waterIntakesByHour)
    .map(([hour, amount]) => ({ hour, amount }))
    .sort((a, b) => {
      const hourA = parseInt(a.hour.split(':')[0]);
      const hourB = parseInt(b.hour.split(':')[0]);
      return hourA - hourB;
    })
    .slice(-4);
    
  // Add empty slots if less than 4
  while (latestWaterIntakes.length < 4) {
    latestWaterIntakes.unshift({ hour: '-', amount: 0 });
  }
  
  const handleSetGoal = () => {
    onSetWaterGoal(newGoal);
    setIsGoalDialogOpen(false);
  };
  
  const handleReminderChange = (time: string) => {
    setReminderTime(time);
  };
  
  return (
    <section className="p-4 border-b">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold">Water Intake</h2>
        <Dialog open={isGoalDialogOpen} onOpenChange={setIsGoalDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="link" className="text-primary text-sm font-medium p-0">Set Goal</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Set Daily Water Goal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <p className="text-sm text-gray-500">
                Set your daily water intake target in milliliters (ml). 
                The recommended amount is 2000-3000ml per day.
              </p>
              <Input
                type="number"
                value={newGoal}
                onChange={(e) => setNewGoal(parseInt(e.target.value))}
                min={500}
                max={5000}
                step={100}
              />
              <Button onClick={handleSetGoal} className="w-full">
                Save Goal
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="flex items-center justify-between mb-4">
        <div className="flex space-x-2">
          {latestWaterIntakes.map((intake, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="w-12 h-20 bg-blue-100 rounded-xl relative overflow-hidden">
                <div 
                  className="absolute bottom-0 w-full bg-primary"
                  style={{ 
                    height: `${Math.min(Math.round((intake.amount / 500) * 100), 100)}%`,
                  }}
                ></div>
              </div>
              <span className="text-xs mt-1">{intake.hour}</span>
            </div>
          ))}
        </div>
        
        <div className="flex flex-col items-end">
          <Button 
            onClick={() => onAddWaterIntake(250)} 
            size="icon" 
            className="bg-primary text-white rounded-full h-12 w-12"
          >
            <PlusIcon className="h-6 w-6" />
          </Button>
          <span className="text-xs mt-1 text-gray-500">Add water</span>
        </div>
      </div>
      
      <div className="flex justify-between text-sm text-gray-500">
        <span>Next reminder: {reminderTime}</span>
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="link" className="text-primary p-0">Edit</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Set Reminder Time</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <p className="text-sm text-gray-500">
                Set a reminder to help you stay hydrated throughout the day.
              </p>
              <Input
                type="time"
                value={reminderTime}
                onChange={(e) => handleReminderChange(e.target.value)}
              />
              <Button onClick={() => {}} className="w-full">
                Save Reminder
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
