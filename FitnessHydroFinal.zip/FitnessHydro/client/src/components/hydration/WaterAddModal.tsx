import { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Minus, Plus, Droplet } from 'lucide-react';

interface WaterAddModalProps {
  onAddWater: (amount: number) => void;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function WaterAddModal({ onAddWater, open, onOpenChange }: WaterAddModalProps) {
  const [amount, setAmount] = useState(250);
  
  const handleIncreaseWater = () => {
    setAmount(prev => prev + 50);
  };
  
  const handleDecreaseWater = () => {
    setAmount(prev => Math.max(50, prev - 50));
  };
  
  const handleQuickSelect = (selectedAmount: number) => {
    setAmount(selectedAmount);
  };
  
  const handleSaveWaterIntake = () => {
    onAddWater(amount);
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-bold text-lg">Add Water Intake</DialogTitle>
        </DialogHeader>
        
        <div className="flex justify-center mb-6">
          <div className="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center">
            <Droplet className="h-16 w-16 text-primary" />
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
            <div className="flex items-center">
              <Button
                variant="outline"
                size="icon"
                onClick={handleDecreaseWater}
                className="h-10 w-10 rounded-l-lg"
              >
                <Minus className="h-5 w-5" />
              </Button>
              <div className="h-10 flex-1 border-t border-b flex items-center justify-center">
                <span className="font-bold">{amount} ml</span>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={handleIncreaseWater}
                className="h-10 w-10 rounded-r-lg"
              >
                <Plus className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quick Select</label>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={amount === 100 ? "default" : "outline"}
                onClick={() => handleQuickSelect(100)}
                className="py-2 text-sm"
              >
                100 ml
              </Button>
              <Button
                variant={amount === 250 ? "default" : "outline"}
                onClick={() => handleQuickSelect(250)}
                className="py-2 text-sm"
              >
                250 ml
              </Button>
              <Button
                variant={amount === 500 ? "default" : "outline"}
                onClick={() => handleQuickSelect(500)}
                className="py-2 text-sm"
              >
                500 ml
              </Button>
            </div>
          </div>
          
          <div className="pt-2">
            <Button onClick={handleSaveWaterIntake} className="w-full py-6">
              Add to Journal
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
