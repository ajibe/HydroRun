import { useEffect, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Pause, Square } from 'lucide-react';
import { useGeolocation, GeolocationState } from '@/hooks/use-geolocation';

interface ActivityRecordingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFinishRecording: (data: any) => void;
}

export default function ActivityRecordingModal({ 
  open, 
  onOpenChange,
  onFinishRecording
}: ActivityRecordingModalProps) {
  const {
    coordinates,
    isRecording,
    routeCoordinates,
    startTime,
    elapsedTime,
    distance,
    isPaused,
    startRecording,
    pauseRecording,
    resumeRecording,
    stopRecording
  } = useGeolocation();
  
  const [mapImageUrl, setMapImageUrl] = useState<string>('https://images.unsplash.com/photo-1550850839-8dc894ed385a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80');
  
  // Format time display (MM:SS)
  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Format pace display (MM:SS/km)
  const formatPace = (distanceKm: number, timeMs: number) => {
    if (distanceKm === 0) return '--:--';
    
    const totalMinutes = timeMs / (1000 * 60);
    const paceMinutesPerKm = totalMinutes / distanceKm;
    
    const paceMinutes = Math.floor(paceMinutesPerKm);
    const paceSeconds = Math.floor((paceMinutesPerKm - paceMinutes) * 60);
    
    return `${paceMinutes.toString().padStart(2, '0')}:${paceSeconds.toString().padStart(2, '0')}`;
  };
  
  // Start recording when modal is opened
  useEffect(() => {
    if (open && !isRecording) {
      startRecording();
    }
  }, [open, isRecording, startRecording]);
  
  const handlePauseRecording = () => {
    if (isPaused) {
      resumeRecording();
    } else {
      pauseRecording();
    }
  };
  
  const handleStopRecording = () => {
    const activityData = stopRecording();
    onFinishRecording(activityData);
    onOpenChange(false);
  };
  
  const handleCancelRecording = () => {
    stopRecording();
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="p-0 max-w-full h-full md:h-auto md:max-w-3xl sm:max-w-xl">
        <div className="flex flex-col h-full">
          <header className="p-4 flex items-center justify-between text-white bg-black">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCancelRecording}
              className="text-white"
            >
              <X className="h-6 w-6" />
            </Button>
            <div className="text-center">
              <h3 className="font-bold">Recording Activity</h3>
              <p className="text-sm opacity-80">Outdoor Run</p>
            </div>
            <div className="w-10"></div> {/* Empty div for flex spacing */}
          </header>
          
          <div className="flex-1 flex flex-col">
            <div className="flex-1 bg-gray-700 relative">
              {/* Map would go here, using placeholder image for now */}
              <div
                className="w-full h-full bg-cover bg-center opacity-90"
                style={{ backgroundImage: `url(${mapImageUrl})` }}
              ></div>
            </div>
            
            <div className="bg-black text-white p-4">
              <div className="flex justify-between mb-6 text-center">
                <div>
                  <p className="text-3xl font-bold">{distance.toFixed(2)}</p>
                  <p className="text-sm opacity-80">Distance (km)</p>
                </div>
                <div>
                  <p className="text-3xl font-bold font-mono">{formatTime(elapsedTime)}</p>
                  <p className="text-sm opacity-80">Time</p>
                </div>
                <div>
                  <p className="text-3xl font-bold">{formatPace(distance, elapsedTime)}</p>
                  <p className="text-sm opacity-80">Pace (min/km)</p>
                </div>
              </div>
              
              <div className="flex justify-center space-x-4">
                <Button
                  onClick={handlePauseRecording}
                  size="lg"
                  variant="ghost"
                  className="h-16 w-16 rounded-full bg-white text-black"
                >
                  {isPaused ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    </svg>
                  ) : (
                    <Pause className="h-8 w-8" />
                  )}
                </Button>
                <Button
                  onClick={handleStopRecording}
                  size="lg"
                  variant="destructive"
                  className="h-16 w-16 rounded-full"
                >
                  <Square className="h-8 w-8" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
