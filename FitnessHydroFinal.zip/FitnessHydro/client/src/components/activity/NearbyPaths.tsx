import { Card } from '@/components/ui/card';
import { UserCircle } from 'lucide-react';

interface NearbyPath {
  id: number;
  title: string;
  description: string;
  distance: number;
  imageUrl: string;
  runnersCount: number;
}

interface NearbyPathsProps {
  paths: NearbyPath[];
  onSelectPath: (pathId: number) => void;
}

export default function NearbyPaths({ paths, onSelectPath }: NearbyPathsProps) {
  return (
    <div>
      <h3 className="font-semibold mb-3">Explore Nearby Paths</h3>
      <div className="space-y-3">
        {paths.map((path) => (
          <Card 
            key={path.id}
            className="flex bg-white border p-3 rounded-lg shadow-sm cursor-pointer hover:border-primary transition-colors"
            onClick={() => onSelectPath(path.id)}
          >
            <div className="h-16 w-16 bg-gray-200 rounded overflow-hidden mr-3">
              <div 
                className="h-full w-full bg-cover bg-center"
                style={{ backgroundImage: `url(${path.imageUrl})` }}
              ></div>
            </div>
            <div className="flex-1">
              <div className="flex justify-between">
                <h4 className="font-medium">{path.title}</h4>
                <span className="text-sm text-gray-500">{path.distance.toFixed(1)} km away</span>
              </div>
              <p className="text-sm text-gray-600">{path.description}</p>
              <div className="flex items-center mt-1">
                <div className="flex -space-x-1 mr-2">
                  {Array.from({ length: Math.min(3, path.runnersCount) }).map((_, i) => (
                    <div key={i} className="h-5 w-5 rounded-full bg-gray-300 border border-white flex items-center justify-center">
                      <UserCircle className="h-5 w-5 text-gray-500" />
                    </div>
                  ))}
                </div>
                <span className="text-xs text-gray-500">+{path.runnersCount} runners today</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
