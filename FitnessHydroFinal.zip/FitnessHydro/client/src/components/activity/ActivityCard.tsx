import { useState } from 'react';
import { formatDistance, formatRelative } from 'date-fns';
import { Share, Edit, TrendingUp, Cloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ActivityCardProps {
  title: string;
  date: string;
  imageUrl: string;
  distance: number;
  duration: string;
  pace: string;
  elevationGain: number;
  weather: string;
  temperature: number;
  onShare: () => void;
  onEdit: () => void;
}

export default function ActivityCard({
  title,
  date,
  imageUrl,
  distance,
  duration,
  pace,
  elevationGain,
  weather,
  temperature,
  onShare,
  onEdit
}: ActivityCardProps) {
  return (
    <Card className="bg-white border rounded-xl shadow-sm overflow-hidden mb-4">
      <div className="h-48 bg-gray-200 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black opacity-60"></div>
        <div 
          className="h-full w-full bg-cover bg-center"
          style={{ backgroundImage: `url(${imageUrl})` }}
        ></div>
        <div className="absolute bottom-0 left-0 right-0 p-3 text-white">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium">{title}</h3>
              <p className="text-sm opacity-90">{date}</p>
            </div>
            <div className="flex space-x-2">
              <Button 
                onClick={onShare} 
                size="icon" 
                variant="ghost" 
                className="bg-white bg-opacity-20 h-9 w-9 rounded-full"
              >
                <Share className="h-5 w-5 text-white" />
              </Button>
              <Button 
                onClick={onEdit} 
                size="icon" 
                variant="ghost" 
                className="bg-white bg-opacity-20 h-9 w-9 rounded-full"
              >
                <Edit className="h-5 w-5 text-white" />
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="p-3">
        <div className="flex justify-between pb-2 border-b">
          <div className="text-center">
            <p className="text-sm text-gray-500">Distance</p>
            <p className="font-semibold">{distance.toFixed(1)} km</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">Duration</p>
            <p className="font-semibold">{duration}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">Avg. Pace</p>
            <p className="font-semibold">{pace}/km</p>
          </div>
        </div>
        <div className="mt-2 flex justify-between items-center">
          <div className="flex items-center">
            <TrendingUp className="h-5 w-5 text-primary mr-1" />
            <span className="text-sm">{elevationGain}m elevation gain</span>
          </div>
          <div className="flex items-center">
            <Cloud className="h-5 w-5 text-blue-400 mr-1" />
            <span className="text-sm">{weather}, {temperature}°C</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
